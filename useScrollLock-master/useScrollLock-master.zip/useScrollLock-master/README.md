# useScrollLock Hook

A scroll lock hook example for React applications.

This hook is a companion to the LogRocket (article)[]

## Features

* Dynamic scrollbar compensation
