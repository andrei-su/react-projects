import PLP from "./PLP";

const Main = () => (
  <main>
    <PLP />
    <button className="button--help">&#10067;</button>
  </main>
);

export default Main;
