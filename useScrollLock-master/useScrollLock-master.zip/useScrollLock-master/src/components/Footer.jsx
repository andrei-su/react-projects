import React from "react";

const Footer = () => {
  return <footer>Connect with us on our social networks!</footer>;
};

export default Footer;
